const express = require('express');
const shell = require('shelljs');
const app = express();
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const { body, validationResult } = require('express-validator');

app.use(express.json({ limit: '500mb' }));
app.use(express.urlencoded({ extended: true, limit: '500mb' }));

const uploadDir = 'uploads';

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalFilename);
    }
});
const upload = multer({ storage: storage });
const port = 6546;
const cors = require('cors')
 app.use(cors())
 


app.use(express.json());

app.post('/installpath', (req, res) => {
    // 单路径安装接口
    const { path_item, serial } = req.body;
    
    if (shell.cd(path_item)) {
        const str = shell.ls();
        const hsp = str[0];
        const hap = str[1];
        if (serial) {
            const hspinstall = shell.exec(`hdc -t ${serial} install ${hsp}`);

            if (hspinstall.code === 0) {
                const hapinstall = shell.exec(`hdc -t ${serial} install ${hap}`);
                if (hapinstall) {
                    res.json({ message: '安装完成！' });
                }
            }
        } else {
            const hspinstall = shell.exec(`hdc install ${hsp}`);
            if (hspinstall.code === 0) {
                const hapinstall = shell.exec(`hdc install ${hap}`);
                if (hapinstall.code === 0) {
                    res.json({ message: '安装完成！' });
                }
            }
        }

        
    } else {
        console.log('切换目录失败');
        res.json({ error: '切换目录失败' });
    }
});


app.post('/upload', upload.single('zipFile'),[ body('serial').optional()], (req, res) => {
    // 压缩包安装接口
    const zipFilePath = path.join(uploadDir, req.file.filename);
    const zip = new AdmZip(zipFilePath);
    const { serial } = req.body;
    

    try {
        const firstEntry = zip.getEntries()[0];
        const outputDir = path.join(uploadDir, firstEntry.entryName);

        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir);
        }
        zip.extractEntryTo(firstEntry.entryName, outputDir, false);

        const absoluteOutputDir = path.resolve(outputDir);
        shell.cd(absoluteOutputDir)
        if (shell.cd(absoluteOutputDir)) {
            const lsStr = shell.ls();
            const hsp = lsStr[0];
            const hap = lsStr[1];

            new Promise((resolve, reject) => {
                if (serial) {
                    const hspinstall = shell.exec(`hdc -t ${serial} install ${hsp}`);
                    if (hspinstall.code === 0) {
                        const hapintall =  shell.exec(`hdc -t ${serial} install ${hap}`);
                        if (hapintall.code === 0) {
                            resolve();
                        }
                    }
                    
                } else {
                    const hspinstall = shell.exec(`hdc install ${hsp}`);
                    if (hspinstall.code === 0) {
                        const hapinstall = shell.exec(`hdc install ${hap}`);
                        if (hapinstall.code === 0) {
                            resolve();
                        }
                    } 
                }
            }).then(() => {
                const cdshell = shell.cd("..");
                if (cdshell.code === 0) {
                    const cdshell2 = shell.cd("..");
                    if (cdshell2.code === 0) {
                        const files = fs.readdirSync(uploadDir);
                        files.forEach((file) => {
                            const filePath = path.join(uploadDir, file);
                            if (fs.statSync(filePath).isFile()) {
                                fs.unlinkSync(filePath);
                            } else if (fs.statSync(filePath).isDirectory()) {
                                
                                shell.rm('-rf', filePath);
                            }
                        });

                        console.log('uploads文件夹已清空');
                        res.json({ message: '安装完成！' });
                    }
                }
            })
        }
        
    } catch (error) {
        console.error('解压文件出错:', error);
        res.send('文件上传成功，但解压出错');
        console.log('错误详情:', error.message);
    }
});

app.listen(port, () => {
    console.log(`.............服务器在端口 ${port} 上运行..............`)
    console.log("                       _oo0oo_                      ")
    console.log("                      o8888888o                     ")
    console.log('                      88" . "88                     ')
    console.log("                      (| -_- |)                     ")
    console.log("                      0\\  =  /0                    ")
    console.log("                   ___/‘---’\\___                   ")
    console.log("                  .' \\|       |/ '.                ")
    console.log("                 / \\\\|||  :  |||// \\             ")
    console.log("                / _||||| -卍-|||||_ \\              ")
    console.log("               |   | \\\\\\  -  /// |   |           ")
    console.log("               | \\_|  ''\\---/''  |_/ |            ")
    console.log("               \\  .-\\__  '-'  ___/-. /            ")
    console.log("             ___'. .'  /--.--\\  '. .'___           ")
    console.log("       | | :  ‘- \\‘.;‘\\ _ /’;.’/ - ’ : | |        ")
    console.log("         \\  \\ ‘_.   \\_ __\\ /__ _/   .-’ /  /    ")
    console.log("    =====‘-.____‘.___ \\_____/___.-’___.-’=====     ")
    console.log("                       ‘=---=’                      ")
    console.log("                                                    ")
    console.log("...................佛祖保佑 ,永无BUG.................")
});